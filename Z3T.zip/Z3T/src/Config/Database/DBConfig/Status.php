<?php
	namespace Config\Database\DBConfig;

    class Status {
        public static $IDStatus = 'IDStatus';
        public static $StatusNazwa = 'StatusNazwa';
    }

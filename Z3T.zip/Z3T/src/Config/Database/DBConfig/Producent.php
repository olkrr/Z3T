<?php
	namespace Config\Database\DBConfig;

    class Producent {
        public static $IDProducent = 'IDProducent';
        public static $ProducentNazwa = 'ProducentNazwa';   
    }

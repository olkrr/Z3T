<?php
	namespace Config\Database\DBConfig;

    class TypMyjki {
        public static $IDTypMyjki       = 'IDTypMyjki';
        public static $NazwaTypMyjki    = 'NazwaTypMyjki';
    }

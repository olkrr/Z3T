<?php
	namespace Config\Database\DBConfig;

    class Osprzet {
        public static $IDOsprzet = 'IDOsprzet';
        public static $OsprzetNazwa = 'OsprzetNazwa';   
    }

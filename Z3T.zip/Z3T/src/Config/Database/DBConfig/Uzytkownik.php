<?php
	namespace Config\Database\DBConfig;

    class Uzytkownik {
        public static $ID = 'ID';
        public static $Login = 'Login';
		public static $Haslo = 'Haslo';
    }

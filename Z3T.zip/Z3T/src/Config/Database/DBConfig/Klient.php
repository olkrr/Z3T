<?php
	namespace Config\Database\DBConfig;

    class Klient {
        public static $IDKlient = 'IDKlient';
        public static $Imie = 'Imie';
		public static $Nazwisko = 'Nazwisko';
		public static $NazwaFirmy = 'NazwaFirmy';
		public static $NumerTelefonu = 'NumerTelefonu';
		public static $Email = 'Email';
        public static $Ulica = 'Ulica';
        public static $NumerDomu = 'NumerDomu';
        public static $Miejscowosc = 'Miejscowosc';
        public static $KodPocztowy = 'KodPocztowy';
        public static $Uwagi = 'Uwagi';
    }
